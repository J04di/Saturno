import { exec } from "child_process"
import path from "path"
import fetch from "node-fetch"
import fs from "fs"
import { tmpdir } from "os"
import { createWriteStream } from "fs"
import https from "https"

const scriptPath = path.resolve("./python/yt_scraper.py")

export default {
  commands: ["play", "yta", "ytmp3", "playaudio", "play2", "ytv", "ytmp4", "mp4"],
  flags: ["isGroup"],
  handled: async (venus, { m, args, command }) => {
    try {
      const text = args.join(" ")
      if (!text) {
        return venus.sendMessage(m.chat, { text: "❀ Por favor, ingresa el nombre o enlace del video." }, { quoted: m })
      }

      const type = ["play2", "ytv", "ytmp4", "mp4"].includes(command) ? "video" : "audio"
      const data = await runPythonScraper(text, type)

      const { title, uploader, thumbnail, duration, view_count, webpage_url, url } = data

      const info = `「✦」Descargando *<${title}>*\n\n` +
        `> ✧ Canal » *${uploader}*\n` +
        `> ✰ Vistas » *${formatViews(view_count)}*\n` +
        `> ⴵ Duración » *${formatDuration(duration)}*\n` +
        `> 🜸 Link » ${webpage_url}`

      const thumb = await fetch(thumbnail).then(r => r.buffer())

      await venus.sendMessage(m.chat, {
        text: info,
        contextInfo: {
          externalAdReply: {
            title: global.botname || "Bot",
            body: global.author || "Desarrollador",
            mediaType: 1,
            previewType: 0,
            mediaUrl: webpage_url,
            sourceUrl: webpage_url,
            thumbnail: thumb,
            renderLargerThumbnail: true
          }
        }
      }, { quoted: m })

      // Descarga el archivo temporalmente y lo envía
      const tempPath = path.join(tmpdir(), `${title.replace(/[^\w\s]/gi, "")}.${type === "audio" ? "mp3" : "mp4"}`)
      await downloadFile(url, tempPath)

      const media = type === "audio"
        ? { audio: fs.readFileSync(tempPath), mimetype: "audio/mpeg", fileName: `${title}.mp3` }
        : { video: fs.readFileSync(tempPath), mimetype: "video/mp4", caption: title }

      await venus.sendMessage(m.chat, media, { quoted: m })
      fs.unlinkSync(tempPath) // eliminar archivo temporal

    } catch (e) {
      console.error(e)
      venus.sendMessage(m.chat, { text: `⚠︎ Ocurrió un error:\n${e.message || e}` }, { quoted: m })
    }
  }
}

function runPythonScraper(query, type = "audio") {
  return new Promise((resolve, reject) => {
    exec(`python3 "${scriptPath}" "${query}" ${type}`, (error, stdout, stderr) => {
      if (error || stderr) return reject(stderr || error)
      try {
        const json = JSON.parse(stdout)
        resolve(json)
      } catch {
        reject("❌ Error interpretando la respuesta del script.")
      }
    })
  })
}

function downloadFile(url, outputPath) {
  return new Promise((resolve, reject) => {
    const file = createWriteStream(outputPath)
    https.get(url, response => {
      response.pipe(file)
      file.on("finish", () => {
        file.close(resolve)
      })
    }).on("error", err => {
      fs.unlink(outputPath, () => reject(err.message))
    })
  })
}

function formatViews(views) {
  if (!views) return "No disponible"
  if (views >= 1_000_000_000) return `${(views / 1_000_000_000).toFixed(1)}B (${views.toLocaleString()})`
  if (views >= 1_000_000) return `${(views / 1_000_000).toFixed(1)}M (${views.toLocaleString()})`
  if (views >= 1_000) return `${(views / 1_000).toFixed(1)}k (${views.toLocaleString()})`
  return views.toString()
}

function formatDuration(seconds) {
  const mins = Math.floor(seconds / 60)
  const secs = seconds % 60
  return `${mins}m ${secs}s`
}