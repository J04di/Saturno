const owners = [
    "5219961079694@s.whatsapp.net",
    "593963312646@s.whatsapp.net",
    "593988484435@s.whatsapp.net", 
    "113228357103686@lid",
    "6949307429109@lid"
]
export { owners }